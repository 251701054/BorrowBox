
const API_URL = "http://localhost:3000/api";

// HTML elements
const equipmentList = document.getElementById("equipment-list");
const equipmentSelect = document.getElementById("equipment-id");
const equipmentSearch = document.getElementById("equipment-search");
const searchMessage = document.getElementById("search-message");
const borrowForm = document.getElementById("borrow-form");
const borrowDate = document.getElementById("borrow-date");
const dueDate = document.getElementById("due-date");
const borrowMessage = document.getElementById("borrow-message");
const borrowingList = document.getElementById("borrowing-list");

let allEquipment = [];

// Format date as YYYY-MM-DD using local time
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

// Parse a SQL date or date-only string without timezone shifting
function parseDateOnly(value) {
    const dateString = String(value).slice(0, 10);
    const parts = dateString.split("-").map(Number);

    if (parts.length !== 3 || parts.some(Number.isNaN)) {
        return new Date(NaN);
    }

    return new Date(parts[0], parts[1] - 1, parts[2]);
}

// Set default borrowing dates
const today = new Date();
today.setHours(0, 0, 0, 0);

const todayString = formatDate(today);

const nextWeek = new Date(today);
nextWeek.setDate(nextWeek.getDate() + 7);

const nextWeekString = formatDate(nextWeek);

borrowDate.min = todayString;
borrowDate.value = todayString;
dueDate.min = todayString;
dueDate.value = nextWeekString;

// Update due date when borrow date changes
borrowDate.addEventListener("change", function () {
    dueDate.min = borrowDate.value;

    if (dueDate.value <= borrowDate.value) {
        const newDueDate = parseDateOnly(borrowDate.value);
        newDueDate.setDate(newDueDate.getDate() + 7);
        dueDate.value = formatDate(newDueDate);
    }
});

// Display equipment cards and update the borrowing dropdown
function renderEquipment(equipment) {
    equipmentList.replaceChildren();

    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Choose equipment";
    equipmentSelect.replaceChildren(placeholder);

    if (equipment.length === 0) {
        equipmentList.textContent = "No matching equipment found.";
        return;
    }

    equipment.forEach(function (item) {
        const card = document.createElement("div");
        card.className = "equipment-card";

        const name = document.createElement("h3");
        name.textContent = item.name;

        const category = document.createElement("p");
        category.textContent = "Category: " + item.category;

        const description = document.createElement("p");
        description.textContent =
            item.description || "No description available";

        const quantity = document.createElement("p");
        quantity.textContent =
            "Available quantity: " + item.available_quantity;

        card.append(name, category, description, quantity);
        equipmentList.appendChild(card);

        const option = document.createElement("option");
        option.value = item.equipment_id;
        option.textContent =
            `${item.name} (${item.available_quantity} available)`;
        option.disabled = Number(item.available_quantity) <= 0;

        equipmentSelect.appendChild(option);
    });
}

// Load equipment from the backend
async function loadEquipment() {
    try {
        const response = await fetch(`${API_URL}/equipment`);

        if (!response.ok) {
            throw new Error("Could not load equipment.");
        }

        allEquipment = await response.json();
        filterEquipment();
    } catch (error) {
        equipmentList.textContent =
            "Unable to load equipment. Check that the backend is running.";

        console.error("Equipment error:", error);
    }
}

// Search equipment by name or category
function filterEquipment() {
    const query = equipmentSearch.value.trim().toLowerCase();

    const filteredEquipment = allEquipment.filter(function (item) {
        const name = String(item.name || "").toLowerCase();
        const category = String(item.category || "").toLowerCase();

        return name.includes(query) || category.includes(query);
    });

    renderEquipment(filteredEquipment);

    searchMessage.textContent = query
        ? `${filteredEquipment.length} matching item(s) found.`
        : "";
}

equipmentSearch.addEventListener("input", filterEquipment);

// Load borrowing history and calculate overdue display status
async function loadBorrowingHistory() {
    try {
        const response = await fetch(`${API_URL}/borrowings`);

        if (!response.ok) {
            throw new Error("Failed to load borrowing history.");
        }

        const borrowings = await response.json();
        borrowingList.replaceChildren();

        if (borrowings.length === 0) {
            borrowingList.textContent = "No borrowing records found.";
            return;
        }

        const currentDay = new Date();
        currentDay.setHours(0, 0, 0, 0);

        borrowings.forEach(function (item) {
            const card = document.createElement("div");
            card.className = "equipment-card";

            const name = document.createElement("h3");
            name.textContent =
                item.equipment_name || item.name || "Equipment";

            const user = document.createElement("p");
            user.textContent =
                "Borrower: " + (item.full_name || "Unknown");

            const dates = document.createElement("p");
            dates.textContent =
                `Borrowed: ${String(item.borrow_date).slice(0, 10)} | ` +
                `Due: ${String(item.due_date).slice(0, 10)}`;

            const due = parseDateOnly(item.due_date);

            let currentStatus = item.status;

            if (
                item.status !== "Returned" &&
                !Number.isNaN(due.getTime()) &&
                due < currentDay
            ) {
                currentStatus = "Overdue";
            }

            const status = document.createElement("p");
            status.className = "status-badge";
            status.textContent = currentStatus;
            status.classList.add(
                currentStatus.toLowerCase().replace(/\s+/g, "-")
            );

            card.append(name, user, dates, status);

            // Add return button for items still marked Borrowed
            if (item.status === "Borrowed") {
                const returnButton = document.createElement("button");
                returnButton.type = "button";
                returnButton.textContent = "Return Equipment";

                returnButton.addEventListener("click", async function () {
                    returnButton.disabled = true;
                    returnButton.textContent = "Returning...";

                    try {
                        const returnResponse = await fetch(
                            `${API_URL}/borrowings/${item.borrowing_id}/return`,
                            { method: "PATCH" }
                        );

                        const result = await returnResponse.json();

                        if (!returnResponse.ok) {
                            throw new Error(
                                result.error || "Could not return equipment."
                            );
                        }

                        alert("Equipment returned successfully!");

                        await loadEquipment();
                        await loadBorrowingHistory();
                    } catch (error) {
                        alert(error.message);
                        returnButton.disabled = false;
                        returnButton.textContent = "Return Equipment";
                    }
                });

                card.appendChild(returnButton);
            }

            borrowingList.appendChild(card);
        });
    } catch (error) {
        borrowingList.textContent =
            "Unable to load borrowing history.";

        console.error("History error:", error);
    }
}

// Submit a borrowing request
borrowForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    if (dueDate.value <= borrowDate.value) {
        borrowMessage.textContent =
            "Due date must be after the borrow date.";
        return;
    }

    const requestData = {
        user_id: Number(document.getElementById("user-id").value),
        equipment_id: Number(equipmentSelect.value),
        borrow_date: borrowDate.value,
        due_date: dueDate.value
    };

    const submitButton =
        borrowForm.querySelector('button[type="submit"]');

    submitButton.disabled = true;
    borrowMessage.textContent = "Submitting your request...";

    try {
        const response = await fetch(`${API_URL}/borrowings`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(requestData)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Unable to submit borrowing request."
            );
        }

        borrowMessage.textContent =
            "Borrow request submitted successfully!";

        borrowForm.reset();

        borrowDate.min = todayString;
        borrowDate.value = todayString;
        dueDate.min = todayString;
        dueDate.value = nextWeekString;

        await loadEquipment();
        await loadBorrowingHistory();
    } catch (error) {
        borrowMessage.textContent = error.message;
    } finally {
        submitButton.disabled = false;
    }
});

// Load data when the page opens
loadEquipment();
loadBorrowingHistory();
